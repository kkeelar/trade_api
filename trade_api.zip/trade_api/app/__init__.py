# app/__init__.py
"""
This makes 'app' a Python package.
"""
